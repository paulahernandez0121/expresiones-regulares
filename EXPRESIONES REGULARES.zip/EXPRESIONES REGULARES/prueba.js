
function sub(){
var product = document.getElementById("caja").value;
var expreg = new RegExp("^[A-Z]{1,2}\\s\\d{4}\\s([B-D]|[F-H]|[J-N]|[P-T]|[V-Z]){3}$");

if(expreg.test(product)){

    alert("Expresion Valida"+product)
}
else{
	alert("Expresion NO Valida"+product)
}
}

